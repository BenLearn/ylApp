document.write('<link rel="stylesheet" href="../AmazeUI-2.7.2/assets/css/amazeui.flat.css"> <!--圆角版 Amaze UI CSS-->');
document.write('<link rel="stylesheet" href="../AmazeUI-2.7.2/assets/css/app.css">');
document.write('<link rel="stylesheet" href="../stylesheets/swiper.css">');
document.write('<link rel="stylesheet" href="../iconfont/iconfont.css"> <!- 字体图标库 ->');
document.write('<link rel="stylesheet" href="../stylesheets/mescroll.min.css">');
document.write('<link rel="stylesheet" href="../stylesheets/layer.css">');
document.write('<link rel="stylesheet" href="../stylesheets/form.css">');
document.write('<link rel="stylesheet" href="../stylesheets/common.css">');